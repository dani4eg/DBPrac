create trigger BI_STUDENTS
	before insert
	on STUDENTS
	for each row
begin   
  if :NEW."STUDENT_ID" is null then 
    select "STUDENTS_SEQ".nextval into :NEW."STUDENT_ID" from dual; 
  end if; 
end; 
